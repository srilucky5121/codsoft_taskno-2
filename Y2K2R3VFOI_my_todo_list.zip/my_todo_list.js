document.addEventListener('DOMContentLoaded', function() {
    const taskInput = document.getElementById('taskInput');
    const taskList = document.getElementById('taskList');

    // Load tasks from local storage
    loadTasks();

    // Add task
    taskInput.addEventListener('keypress', function(event) {
        if (event.key === 'Enter') {
            addTask(taskInput.value);
            taskInput.value = '';
        }
    });

    // Delete and Edit task
    taskList.addEventListener('click', function(event) {
        if (event.target.tagName === 'BUTTON') {
            const action = event.target.dataset.action;
            const taskItem = event.target.parentElement;
            const taskId = taskItem.dataset.id;

            if (action === 'delete') {
                deleteTask(taskId);
            } else if (action === 'edit') {
                editTask(taskId);
            } else if (action === 'complete') {
                completeTask(taskId);
            }
        }
    });

    function addTask(taskText) {
        if (taskText.trim() !== '') {
            const taskId = Date.now().toString();
            const taskItem = createTaskItem(taskText, taskId);
            taskList.appendChild(taskItem);

            // Save tasks to local storage
            saveTasks();

            taskInput.value = '';
        }
    }

    function createTaskItem(taskText, taskId) {
        const li = document.createElement('li');
        li.dataset.id = taskId;
        li.innerHTML = `
            <span>${taskText}</span>
            <button data-action="edit"><i class="fas fa-edit"></i></button>
            <button data-action="delete"><i class="fas fa-trash-alt"></i></button>
            <button data-action="complete"><i class="fas fa-check"></i></button>
        `;
        return li;
    }

    function deleteTask(taskId) {
        const taskItem = document.querySelector(`[data-id="${taskId}"]`);
        taskList.removeChild(taskItem);

        // Save tasks to local storage
        saveTasks();
    }

    function editTask(taskId) {
        const taskItem = document.querySelector(`[data-id="${taskId}"]`);
        const taskTextElement = taskItem.querySelector('span');
        const updatedTaskText = prompt('Edit task:', taskTextElement.textContent);

        if (updatedTaskText !== null && updatedTaskText.trim() !== '') {
            taskTextElement.textContent = updatedTaskText;

            // Save tasks to local storage
            saveTasks();
        }
    }

    function completeTask(taskId) {
        const taskItem = document.querySelector(`[data-id="${taskId}"]`);
        taskItem.classList.toggle('completed');

        // Save tasks to local storage
        saveTasks();
    }

    function saveTasks() {
        const tasks = Array.from(taskList.children).map(taskItem => ({
            id: taskItem.dataset.id,
            text: taskItem.querySelector('span').textContent,
            completed: taskItem.classList.contains('completed'),
        }));

        localStorage.setItem('tasks', JSON.stringify(tasks));
    }

    function loadTasks() {
        const savedTasks = JSON.parse(localStorage.getItem('tasks')) || [];

        savedTasks.forEach(task => {
            const taskItem = createTaskItem(task.text, task.id);
            if (task.completed) {
                taskItem.classList.add('completed');
            }
            taskList.appendChild(taskItem);
        });
    }
});